from flask import Blueprint

flashcards_bp = Blueprint('flashcards', __name__)

@flashcards_bp.route('/', methods=['GET'])
def placeholder():
    return {'message': 'Flashcards route placeholder'}
