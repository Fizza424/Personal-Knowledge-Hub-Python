from flask import Blueprint, request, jsonify
from app.models import db, Note

notes_bp = Blueprint('notes', __name__)

@notes_bp.route('/', methods=['GET'])
def get_notes():
    user_id = request.args.get('user_id')
    notes = Note.query.filter_by(user_id=user_id).all()
    return jsonify([{'id': n.id, 'title': n.title, 'content': n.content} for n in notes])

@notes_bp.route('/', methods=['POST'])
def add_note():
    data = request.json
    new_note = Note(user_id=data['user_id'], title=data['title'], content=data['content'])
    db.session.add(new_note)
    db.session.commit()
    return jsonify({'message': 'Note added successfully'})

@notes_bp.route('/<int:id>', methods=['PUT'])
def update_note(id):
    note = Note.query.get_or_404(id)
    data = request.json
    note.title = data.get('title', note.title)
    note.content = data.get('content', note.content)
    db.session.commit()
    return jsonify({'message': 'Note updated successfully'})

@notes_bp.route('/<int:id>', methods=['DELETE'])
def delete_note(id):
    note = Note.query.get_or_404(id)
    db.session.delete(note)
    db.session.commit()
    return jsonify({'message': 'Note deleted successfully'})
