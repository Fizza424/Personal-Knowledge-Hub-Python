# Flask app initialization
from flask import Flask

def create_app():
    app = Flask(__name__)
    app.secret_key = 'your_secret_key'

    # Import blueprints
    from app.login import login_blueprint
    from app.notes import notes_blueprint
    from app.timer import timer_blueprint
    from app.progress import progress_blueprint
    from app.flashcards import flashcards_blueprint

    # Register blueprints
    app.register_blueprint(login_blueprint)
    app.register_blueprint(notes_blueprint)
    app.register_blueprint(timer_blueprint)
    app.register_blueprint(progress_blueprint)
    app.register_blueprint(flashcards_blueprint)

    return app
