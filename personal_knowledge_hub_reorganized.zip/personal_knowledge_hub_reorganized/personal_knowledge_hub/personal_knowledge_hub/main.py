# Launches the app
import os
print("Current Working Directory:", os.getcwd())
# main.py
import tkinter as tk
from tkinter import messagebox
from database import init_db
from login import LoginWindow
from notes import NotesApp
from flashcards import FlashcardsApp
from pomodoro import PomodoroApp

class MainApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Personal Knowledge Hub")
        self.root.geometry("300x220")
        self.user_id = None

        # Show login window first
        self.show_login()

    def show_login(self):
        login_window = tk.Toplevel(self.root)
        login_window.grab_set()
        LoginWindow(login_window, self.login_success)

    def login_success(self, user_id):
        self.user_id = user_id
        self.show_dashboard()

    def show_dashboard(self):
        for widget in self.root.winfo_children():
            widget.destroy()

        tk.Label(self.root, text="Welcome to Personal Knowledge Hub!", font=("Helvetica", 12)).pack(pady=10)

        tk.Button(self.root, text="📝 Notes", width=25,
                  command=self.open_notes).pack(pady=5)

        tk.Button(self.root, text="🧠 Flashcards", width=25,
                  command=self.open_flashcards).pack(pady=5)

        tk.Button(self.root, text="⏱️ Pomodoro Timer", width=25,
                  command=self.open_pomodoro).pack(pady=5)

    def open_notes(self):
        notes_window = tk.Toplevel(self.root)
        NotesApp(notes_window, self.user_id)

    def open_flashcards(self):
        flash_window = tk.Toplevel(self.root)
        FlashcardsApp(flash_window, self.user_id)

    def open_pomodoro(self):
        pomo_window = tk.Toplevel(self.root)
        PomodoroApp(pomo_window)

if __name__ == "__main__":
    init_db()  # Ensure the database and tables are created
    root = tk.Tk()
    app = MainApp(root)
    root.mainloop()
