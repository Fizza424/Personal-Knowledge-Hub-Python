# Login/Register GUI
from flask import Blueprint, request, jsonify

login_blueprint = Blueprint('login', __name__)

@login_blueprint.route('/api/login', methods=['POST'])
def login():
    data = request.json
    username = data.get('username')
    password = data.get('password')
    # TODO: Verify from database
    if username == "admin" and password == "admin":
        return jsonify({"message": "Login successful"}), 200
    return jsonify({"message": "Invalid credentials"}), 401
import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import tkinter as tk
from tkinter import messagebox
import sqlite3
from database import get_db_connection

DB_PATH = "hub.db"


# ---------- DATABASE SETUP ----------
def setup_database():
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()


# ---------- DATABASE LOGIC ----------
def register_user(username, password):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    try:
        c.execute("INSERT INTO users (username, password) VALUES (?, ?)",
                  (username, password))
        conn.commit()
        return True
    except sqlite3.IntegrityError:
        return False
    finally:
        conn.close()


def login_user(username, password):
    conn = sqlite3.connect("users.db")
    c = conn.cursor()
    c.execute("SELECT * FROM users WHERE username = ? AND password = ?",
              (username, password))
    result = c.fetchone()
    conn.close()
    return result is not None


# ---------- GUI LOGIC ----------
class LoginWindow:

    def __init__(self, root):
        self.root = root
        self.root.title("Login / Register")
        self.root.geometry("300x200")

        self.username = tk.StringVar()
        self.password = tk.StringVar()

        tk.Label(root, text="Username").pack(pady=5)
        tk.Entry(root, textvariable=self.username).pack()

        tk.Label(root, text="Password").pack(pady=5)
        tk.Entry(root, textvariable=self.password, show='*').pack()

        tk.Button(root, text="Login", command=self.login).pack(pady=5)
        tk.Button(root, text="Register", command=self.register).pack()

    def login(self):
        if login_user(self.username.get(), self.password.get()):
            messagebox.showinfo("Success", "Login successful!")
        else:
            messagebox.showerror("Failed", "Invalid username or password.")

    def register(self):
        if register_user(self.username.get(), self.password.get()):
            messagebox.showinfo("Success", "User registered!")
        else:
            messagebox.showerror("Failed", "Username already exists.")


# ---------- MAIN ----------
if __name__ == "__main__":
    setup_database()
    root = tk.Tk()
    app = LoginWindow(root)
    root.mainloop()
