# Flashcards + quiz
from flask import Blueprint, request, jsonify

flashcards_blueprint = Blueprint('flashcards', __name__)

flashcards = []

@flashcards_blueprint.route('/api/flashcards', methods=['GET'])
def get_flashcards():
    return jsonify(flashcards)

@flashcards_blueprint.route('/api/flashcards', methods=['POST'])
def add_flashcard():
    data = request.json
    flashcard = {
        'id': len(flashcards) + 1,
        'question': data.get('question'),
        'answer': data.get('answer')
    }
    flashcards.append(flashcard)
    return jsonify({'message': 'Flashcard added', 'flashcard': flashcard}), 201

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import tkinter as tk
from tkinter import messagebox, simpledialog, ttk, filedialog
import sqlite3
import random
from reportlab.pdfgen import canvas as pdf_canvas
from reportlab.lib.pagesizes import letter
from database import get_db_connection


DB_PATH = "hub.db"

class FlashcardsApp:
    def __init__(self, master, user_id):
        self.master = master
        self.user_id = user_id
        self.current_index = 0
        self.showing_answer = False
        self.flashcards = []
        self.seen_cards = set()

        self.master.title("Flashcards")
        self.master.geometry("600x400")

        self.create_table()
        self.setup_ui()
        self.load_flashcards()

    def create_table(self):
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS flashcards (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    question TEXT,
                    answer TEXT,
                    subject TEXT
                )
            """)

    def setup_ui(self):
        self.subject_filter = tk.StringVar()

        # Subject filter
        top_frame = tk.Frame(self.master)
        top_frame.pack(pady=5)
        ttk.Label(top_frame, text="Filter by Subject:").pack(side=tk.LEFT)
        self.subject_entry = ttk.Entry(top_frame, textvariable=self.subject_filter, width=20)
        self.subject_entry.pack(side=tk.LEFT, padx=5)
        ttk.Button(top_frame, text="Apply Filter", command=self.load_flashcards).pack(side=tk.LEFT)

        # Card display
        self.card_text = tk.Label(self.master, text="", font=("Arial", 16), wraplength=500, justify="center")
        self.card_text.pack(pady=20)

        # Navigation
        nav_frame = tk.Frame(self.master)
        nav_frame.pack()
        ttk.Button(nav_frame, text="Previous", command=self.prev_card).grid(row=0, column=0, padx=5)
        ttk.Button(nav_frame, text="Flip", command=self.flip_card).grid(row=0, column=1, padx=5)
        ttk.Button(nav_frame, text="Next", command=self.next_card).grid(row=0, column=2, padx=5)

        # Actions
        action_frame = tk.Frame(self.master)
        action_frame.pack(pady=10)
        ttk.Button(action_frame, text="Add Flashcard", command=self.add_flashcard).pack(side=tk.LEFT, padx=5)
        ttk.Button(action_frame, text="Delete Flashcard", command=self.delete_flashcard).pack(side=tk.LEFT, padx=5)
        ttk.Button(action_frame, text="Start Quiz", command=self.start_quiz).pack(side=tk.LEFT, padx=5)
        ttk.Button(action_frame, text="Export PDF", command=self.export_to_pdf).pack(side=tk.LEFT, padx=5)

        # Progress
        self.progress_label = tk.Label(self.master, text="Progress: 0 viewed", font=("Arial", 10))
        self.progress_label.pack(pady=5)

    def load_flashcards(self):
        self.flashcards.clear()
        self.seen_cards.clear()
        subject = self.subject_filter.get()
        with sqlite3.connect(DB_PATH) as conn:
            if subject:
                rows = conn.execute("SELECT id, question, answer, subject FROM flashcards WHERE user_id=? AND subject LIKE ?",
                                    (self.user_id, f"%{subject}%"))
            else:
                rows = conn.execute("SELECT id, question, answer, subject FROM flashcards WHERE user_id=?", (self.user_id,))
            self.flashcards = list(rows)
        self.current_index = 0
        self.showing_answer = False
        self.display_card()

    def display_card(self):
        if not self.flashcards:
            self.card_text.config(text="No flashcards found.")
            self.progress_label.config(text="Progress: 0 viewed")
            return
        card_id, question, answer, _ = self.flashcards[self.current_index]
        if card_id not in self.seen_cards:
            self.seen_cards.add(card_id)
        self.card_text.config(text=answer if self.showing_answer else question)
        self.update_progress()

    def update_progress(self):
        self.progress_label.config(text=f"Progress: {len(self.seen_cards)} of {len(self.flashcards)} viewed")

    def flip_card(self):
        if not self.flashcards: return
        self.showing_answer = not self.showing_answer
        self.display_card()

    def next_card(self):
        if not self.flashcards: return
        self.current_index = (self.current_index + 1) % len(self.flashcards)
        self.showing_answer = False
        self.display_card()

    def prev_card(self):
        if not self.flashcards: return
        self.current_index = (self.current_index - 1) % len(self.flashcards)
        self.showing_answer = False
        self.display_card()

    def add_flashcard(self):
        question = simpledialog.askstring("Question", "Enter question:")
        if not question: return
        answer = simpledialog.askstring("Answer", "Enter answer:")
        if not answer: return
        subject = simpledialog.askstring("Subject", "Optional subject/tag:")
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("INSERT INTO flashcards (user_id, question, answer, subject) VALUES (?, ?, ?, ?)",
                         (self.user_id, question, answer, subject))
        self.load_flashcards()

    def delete_flashcard(self):
        if not self.flashcards: return
        current_id = self.flashcards[self.current_index][0]
        if messagebox.askyesno("Delete", "Delete this flashcard?"):
            with sqlite3.connect(DB_PATH) as conn:
                conn.execute("DELETE FROM flashcards WHERE id=?", (current_id,))
            self.load_flashcards()

    def start_quiz(self):
        if len(self.flashcards) < 4:
            messagebox.showinfo("Quiz Mode", "Add at least 4 flashcards for quiz mode.")
            return

        quiz_win = tk.Toplevel(self.master)
        quiz_win.title("Flashcard Quiz")
        quiz_win.geometry("500x250")

        question_label = tk.Label(quiz_win, text="", font=("Arial", 14), wraplength=450)
        question_label.pack(pady=20)

        buttons_frame = tk.Frame(quiz_win)
        buttons_frame.pack()

        options = [tk.Button(buttons_frame, text="", width=40, command=lambda i=i: check_answer(i))
                   for i in range(4)]
        for btn in options:
            btn.pack(pady=3)

        quiz_set = random.sample(self.flashcards, 4)
        correct = random.choice(quiz_set)
        question_label.config(text=f"Q: {correct[1]}")
        answers = [card[2] for card in quiz_set]
        random.shuffle(answers)

        def check_answer(index):
            if answers[index] == correct[2]:
                messagebox.showinfo("Result", "Correct!")
            else:
                messagebox.showinfo("Result", f"Wrong! Correct: {correct[2]}")
            quiz_win.destroy()

        for i in range(4):
            options[i].config(text=answers[i])

    def export_to_pdf(self):
        if not self.flashcards:
            messagebox.showinfo("Export", "No flashcards to export.")
            return

        file_path = filedialog.asksaveasfilename(defaultextension=".pdf", filetypes=[("PDF files", "*.pdf")])
        if not file_path:
            return

        c = pdf_canvas.Canvas(file_path, pagesize=letter)
        width, height = letter
        y = height - 50

        c.setFont("Helvetica-Bold", 16)
        c.drawString(50, y, "Flashcards Export")
        y -= 30
        c.setFont("Helvetica", 12)

        for idx, (_, q, a, s) in enumerate(self.flashcards):
            text = f"Q{idx+1}: {q}\nA: {a}\nSubject: {s or 'None'}"
            for line in text.split("\n"):
                c.drawString(50, y, line)
                y -= 20
                if y < 60:
                    c.showPage()
                    y = height - 50
        c.save()
        messagebox.showinfo("Export Complete", f"PDF saved to:\n{file_path}")

# Run standalone
if __name__ == "__main__":
    root = tk.Tk()
    FlashcardsApp(root, user_id=1)
    root.mainloop()
