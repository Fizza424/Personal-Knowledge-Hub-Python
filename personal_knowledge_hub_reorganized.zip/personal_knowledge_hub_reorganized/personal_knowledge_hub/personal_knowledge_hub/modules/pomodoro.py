# Pomodoro timer
from flask import Blueprint, jsonify

timer_blueprint = Blueprint('timer', __name__)

@timer_blueprint.route('/api/timer/default', methods=['GET'])
def get_default_timer():
    return jsonify({
        'pomodoro': 25,
        'short_break': 5,
        'long_break': 15
    })

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import tkinter as tk
from tkinter import ttk
import math
from database import get_db_connection

WORK_MIN = 25
SHORT_BREAK_MIN = 5
LONG_BREAK_MIN = 15

class PomodoroApp:
    def __init__(self, master):
        self.master = master
        self.master.title("Pomodoro Timer")
        self.master.geometry("300x350")
        self.master.resizable(False, False)

        self.reps = 0
        self.timer = None

        self.setup_ui()

    def setup_ui(self):
        self.label = tk.Label(self.master, text="Timer", font=("Helvetica", 24))
        self.label.pack(pady=10)

        self.canvas = tk.Canvas(self.master, width=200, height=200, bg="white", highlightthickness=0)
        self.timer_text = self.canvas.create_text(100, 100, text="25:00", fill="black", font=("Courier", 32))
        self.canvas.pack()

        self.start_btn = ttk.Button(self.master, text="Start", command=self.start_timer)
        self.start_btn.pack(pady=5)

        self.reset_btn = ttk.Button(self.master, text="Reset", command=self.reset_timer)
        self.reset_btn.pack(pady=5)

        self.sessions_label = tk.Label(self.master, text="Sessions: 0", font=("Helvetica", 12))
        self.sessions_label.pack(pady=10)

    def reset_timer(self):
        if self.timer:
            self.master.after_cancel(self.timer)
        self.canvas.itemconfig(self.timer_text, text="25:00")
        self.label.config(text="Timer")
        self.sessions_label.config(text="Sessions: 0")
        self.reps = 0

    def start_timer(self):
        self.reps += 1
        work_sec = WORK_MIN * 60
        short_break = SHORT_BREAK_MIN * 60
        long_break = LONG_BREAK_MIN * 60

        if self.reps % 8 == 0:
            self.count_down(long_break)
            self.label.config(text="Long Break", fg="blue")
        elif self.reps % 2 == 0:
            self.count_down(short_break)
            self.label.config(text="Break", fg="green")
        else:
            self.count_down(work_sec)
            self.label.config(text="Work", fg="red")

        completed_sessions = math.floor(self.reps / 2)
        self.sessions_label.config(text=f"Sessions: {completed_sessions}")

    def count_down(self, count):
        minutes = math.floor(count / 60)
        seconds = count % 60
        time_format = f"{minutes:02d}:{seconds:02d}"
        self.canvas.itemconfig(self.timer_text, text=time_format)
        if count > 0:
            self.timer = self.master.after(1000, self.count_down, count - 1)
        else:
            self.start_timer()

# For testing standalone
if __name__ == "__main__":
    root = tk.Tk()
    PomodoroApp(root)
    root.mainloop()
