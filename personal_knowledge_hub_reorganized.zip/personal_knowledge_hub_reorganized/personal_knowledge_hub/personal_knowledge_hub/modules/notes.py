# Notes module
from flask import Blueprint, request, jsonify

notes_blueprint = Blueprint('notes', __name__)

# In-memory mock data
notes = []

@notes_blueprint.route('/api/notes', methods=['GET'])
def get_notes():
    return jsonify(notes)

@notes_blueprint.route('/api/notes', methods=['POST'])
def add_note():
    data = request.json
    note = {
        'id': len(notes) + 1,
        'title': data.get('title'),
        'content': data.get('content')
    }
    notes.append(note)
    return jsonify({'message': 'Note added', 'note': note}), 201

import sys
import os
sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog
import sqlite3
from database import get_db_connection



DB_PATH = "hub.db"

class NotesApp:
    def __init__(self, master, user_id):
        self.master = master
        self.user_id = user_id
        self.master.title("Notes")
        self.master.geometry("600x400")

        self.create_table()
        self.setup_widgets()
        self.load_notes()

    def create_table(self):
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS notes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    user_id INTEGER,
                    title TEXT,
                    content TEXT,
                    tag TEXT
                )
            """)

    def setup_widgets(self):
        # Top controls
        top = tk.Frame(self.master)
        top.pack(pady=10)

        self.search_var = tk.StringVar()
        ttk.Entry(top, textvariable=self.search_var, width=30).pack(side=tk.LEFT, padx=5)
        ttk.Button(top, text="Search", command=self.search_notes).pack(side=tk.LEFT, padx=5)
        ttk.Button(top, text="Add", command=self.add_note).pack(side=tk.LEFT, padx=5)

        # Notes list
        self.tree = ttk.Treeview(self.master, columns=("Title", "Tag"), show="headings")
        self.tree.heading("Title", text="Title")
        self.tree.heading("Tag", text="Tag")
        self.tree.bind("<Double-1>", self.view_note)
        self.tree.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        # Bottom controls
        bottom = tk.Frame(self.master)
        bottom.pack()
        ttk.Button(bottom, text="Edit", command=self.edit_note).pack(side=tk.LEFT, padx=5)
        ttk.Button(bottom, text="Delete", command=self.delete_note).pack(side=tk.LEFT, padx=5)

    def load_notes(self):
        self.tree.delete(*self.tree.get_children())
        with sqlite3.connect(DB_PATH) as conn:
            cursor = conn.execute("SELECT id, title, tag FROM notes WHERE user_id=?", (self.user_id,))
            for row in cursor:
                self.tree.insert("", tk.END, iid=row[0], values=(row[1], row[2]))

    def add_note(self):
        title = simpledialog.askstring("Title", "Note title:")
        if not title: return
        content = simpledialog.askstring("Content", "Note content:")
        tag = simpledialog.askstring("Tag", "Optional tag:")
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("INSERT INTO notes (user_id, title, content, tag) VALUES (?, ?, ?, ?)",
                         (self.user_id, title, content, tag))
        self.load_notes()

    def view_note(self, event=None):
        note_id = self.tree.focus()
        if not note_id: return
        with sqlite3.connect(DB_PATH) as conn:
            note = conn.execute("SELECT title, content, tag FROM notes WHERE id=?", (note_id,)).fetchone()
        messagebox.showinfo(f"{note[0]} [{note[2]}]", note[1])

    def edit_note(self):
        note_id = self.tree.focus()
        if not note_id: return
        with sqlite3.connect(DB_PATH) as conn:
            note = conn.execute("SELECT title, content, tag FROM notes WHERE id=?", (note_id,)).fetchone()
        title = simpledialog.askstring("Edit Title", "Title:", initialvalue=note[0])
        content = simpledialog.askstring("Edit Content", "Content:", initialvalue=note[1])
        tag = simpledialog.askstring("Edit Tag", "Tag:", initialvalue=note[2])
        with sqlite3.connect(DB_PATH) as conn:
            conn.execute("UPDATE notes SET title=?, content=?, tag=? WHERE id=?",
                         (title, content, tag, note_id))
        self.load_notes()

    def delete_note(self):
        note_id = self.tree.focus()
        if not note_id: return
        if messagebox.askyesno("Confirm", "Delete this note?"):
            with sqlite3.connect(DB_PATH) as conn:
                conn.execute("DELETE FROM notes WHERE id=?", (note_id,))
            self.load_notes()

    def search_notes(self):
        keyword = self.search_var.get()
        self.tree.delete(*self.tree.get_children())
        with sqlite3.connect(DB_PATH) as conn:
            rows = conn.execute("""
                SELECT id, title, tag FROM notes
                WHERE user_id=? AND (title LIKE ? OR content LIKE ? OR tag LIKE ?)
            """, (self.user_id, f"%{keyword}%", f"%{keyword}%", f"%{keyword}%")).fetchall()
        for row in rows:
            self.tree.insert("", tk.END, iid=row[0], values=(row[1], row[2]))

# Standalone run for testing
if __name__ == "__main__":
    root = tk.Tk()
    NotesApp(root, user_id=1)
    root.mainloop()
